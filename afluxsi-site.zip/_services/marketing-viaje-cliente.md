
---
title: Marketing Viaje Cliente
description: Diseño de journeys, segmentación, email/SMS, funnels y personalización con IA.
---
## ¿Qué incluye?
- Auditoría del proceso actual
- Diseño del flujo y KPIs
- Implementación con n8n + herramientas existentes
- Capacitación breve y checklist

## Resultados esperados
- Ahorro de horas/semana
- Reducción de errores
- Mayor conversión o retención (según caso)
