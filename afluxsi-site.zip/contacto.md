
---
title: Contacto
description: Agende una auditoría de automatización o escríbanos.
permalink: /contacto/
---
## Solicitar Auditoría {#auditoria}
Complete este breve formulario y le contactaremos con un diagnóstico inicial y un plan de implementación.

<form name="auditoria" method="POST" data-netlify="true">
  <input type="hidden" name="form-name" value="auditoria">
  <p><label>Nombre<br><input type="text" name="nombre" required></label></p>
  <p><label>Email<br><input type="email" name="email" required></label></p>
  <p><label>Empresa<br><input type="text" name="empresa"></label></p>
  <p><label>Industria<br>
    <select name="industria">
      <option>E-commerce & Retail</option>
      <option>Inmobiliaria</option>
      <option>Servicios Profesionales</option>
      <option>Salud, Bienestar y Fitness</option>
      <option>SaaS</option>
      <option>Sin Fines de Lucro</option>
      <option>Educación en Línea</option>
    </select>
  </label></p>
  <p><label>Mensaje (dolor principal)<br><textarea name="mensaje" rows="5"></textarea></label></p>
  <p><button class="btn btn-primary" type="submit">Enviar</button></p>
</form>

> Si prefiere, escríbanos por <a href="https://wa.me/507000000000">WhatsApp</a> o agende por <a href="https://calendly.com/">Calendly</a>.
