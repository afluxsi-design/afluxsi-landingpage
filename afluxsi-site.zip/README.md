
# AfluxSI — Sitio Jekyll listo para GitHub Pages

## Publicación rápida (GitHub Pages)
1. Crea un repositorio en tu cuenta: `afluxsi.com` o el nombre que uses.
2. Sube estos archivos (o usa el ZIP).
3. En **Settings → Pages**, selecciona:
   - Source: **Deploy from a branch**
   - Branch: **main** (o `master`) y carpeta `/ (root)`.
4. Espera a que se buildée. Visita la URL que te muestra.
5. Configura tu dominio en Cloudflare apuntando a GitHub Pages (CNAME).

## Estructura
- `_config.yml` — Configuración del sitio
- `_data/navigation.yml` — Menú
- `_includes/*` — Navegación y pie
- `_layouts/*` — Plantillas
- `_industries/*` — Colección de industrias (páginas pilar)
- `_services/*` — Colección de servicios
- `_posts/*` — Blog
- `assets/` — CSS y JS
- `index.md`, `sobre.md`, `contacto.md` — Páginas principales

## Siguientes pasos
- Edita textos para cada nicho y servicio.
- Añade casos de éxito y guías.
- Conecta el formulario a tu flujo en n8n o servicio de formularios.
